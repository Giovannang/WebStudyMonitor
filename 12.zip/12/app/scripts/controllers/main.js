'use strict'

/**
 * @ngdoc function
 * @name testApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the testApp
 */

var urlTemplate = "http://bea.ep.corp.local/BaseActivites/openUrl.jsp?mode=read&amp;currentModel=etude&amp;idActivite=";
var studiesCreatedPath = "Config\\Studies_Created.csv";
var restApiUrlAllStudies = "http://localhost:8080/api/all";




angular.module('testApp')
  .controller('MainCtrl', function ($window, $scope, $timeout, $interval, $http) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ]
    $scope.selectedFiles = []
    $scope.url = urlTemplate
    if (!$scope.studies)
        $http.get(restApiUrlAllStudies)
        .then(function(response) {
            $scope.studies = response.data
            isStudiesCreated($scope.studies);
            }
         );
   
        


  })




function isStudiesCreated(studies){
/*    var options={"separator" : ";"};
   $.csv.toArrays(studiesCreatedPath, options, function(err, data){
    console.log(data);
});*/
    studies.forEach(function(study){
            study.created = 0;
                
        });
}